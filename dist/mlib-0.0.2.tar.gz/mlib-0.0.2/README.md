# Machine Learning Package
### This is a from-scratch implementation of most of ML learning algorithms
### The package (.whl file) is located in dist folder
### All you need to do is: pip install dist/*.whl
# Supervised ML algorithms
## Linear Regression
### start by "import LinearRegression.LinearRegression as LinearRegression"
