class LinearRegression:
    def __init(self, x, y):
        self.x = x
        self.y = y
    
    def add(self):
        return self.x + self.y