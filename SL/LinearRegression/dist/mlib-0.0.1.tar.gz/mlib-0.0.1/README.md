### This is a from-scratch implementation of most of ML learning algorithms
# Supervised ML algorithms
## Linear Regression
